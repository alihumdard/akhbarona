<div class="row" id="upload_file_computer">
    <div class="col-md-4">
        <label for="rss_feed">Upload destination: </label>
    </div>
    <div class="col-md-4">
        <select name="path_file" class="form-control">
        </select>
    </div>
    <div class="col-md-4">
        <input type="file" name="poup_upload_file">
    </div>
</div>
