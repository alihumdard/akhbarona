<div class="container" style="margin-bottom: 20px;">
    <ul class="nav nav-tabs main-nav-tabs">
        <li class="active"><a href="javascript:;" data-id="tab_main_info">{{$edit?"Edit article":"Add new article"}}</a></li>
        <li><a href="javascript:;" data-id="tab_gallery">Images gallary</a></li>
        <li><a href="javascript:;" data-id="tab_attachments">Attachments</a></li>
    </ul>
</div>
