<?xml version="1.0"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
    <channel>
        <title>The name of your data feed</title>
        <link>
        http://www.example.com</link>
        <description>A description of your content</description>
        <item><title>Red wool sweater</title>
            <link>
            http://www.example.com/item1-info-page.html</link>
            <description>Comfortable and soft, this sweater will keep you warm on those cold winter nights.
            </description>
            <g:image_link>http://www.example.com/image1.jpg</g:image_link>
            <g:price>25</g:price>
            <g:condition>new</g:condition>
            <g:id>1a</g:id>
        </item>
    </channel>
</rss>
