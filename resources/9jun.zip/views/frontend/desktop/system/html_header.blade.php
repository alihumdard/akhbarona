<script async='async' type="text/javascript" src="https://static.criteo.net/js/ld/publishertag.js"></script>
<script>
    window.Criteo = window.Criteo || {};
    window.Criteo.events = window.Criteo.events || [];
</script>

<script async='async' src='https://www.googletagservices.com/tag/js/gpt.js'></script>
<script>
    var googletag = googletag || {};
    googletag.cmd = googletag.cmd || [];
</script>

<script>
    googletag.cmd.push(function() {
        googletag.defineSlot('/1019170/Akhbarona_Top_728x90', [728, 90], 'div-gpt-ad-1521102400350-0').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_970x250_Top', [[970, 250], [970, 90]], 'div-gpt-ad-1521102400350-1').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Top_300x250', [[300, 250], [300, 600]], 'div-gpt-ad-1521102400350-2').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Top_160x600', [160, 600], 'div-gpt-ad-1521102400350-3').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Top_160x600_Left', [160, 600], 'div-gpt-ad-1521102400350-4').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_InArticle_160x600', [[160, 600], [120, 600]], 'div-gpt-ad-1521102400350-5').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_InSection_rectangle', [[300, 250], [336, 280]], 'div-gpt-ad-1521102400350-6').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Footer_Desktop', [[970, 90], [970, 250], [728, 90]], 'div-gpt-ad-1544959375426-0').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Left_Banner_3', [[300, 250], [300, 600]], 'div-gpt-ad-1545660622806-0').addService(googletag.pubads());
        googletag.defineSlot('/1019170/Akhbarona_Under_Article', [[300, 250], [300, 600], [336, 280]], 'div-gpt-ad-1545660755880-0').addService(googletag.pubads());

        googletag.pubads().enableSingleRequest();
        googletag.pubads().collapseEmptyDivs();

        /** BEGIN CRITEO CDB: AFTER GOOGLE SLOT DEFINITIONS, BEFORE ENABLE SERVICES **/
        googletag.pubads().disableInitialLoad();
        Criteo.events.push(function() {
            Criteo.RequestBidsOnGoogleTagSlots(8663, function() {
                Criteo.SetDFPKeyValueTargeting();
                googletag.pubads().refresh();
            }, 2000);
        });
        /** END CRITEO CDB **/

        googletag.enableServices();
    });
</script>
