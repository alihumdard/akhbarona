<div class="dump result @if(isset($parentClass)) {{$parentClass}} @endif" @if(isset($style)) {!! $style !!} @endif>
    <span class="{{$class}}">{{$message}}</span>
</div>
