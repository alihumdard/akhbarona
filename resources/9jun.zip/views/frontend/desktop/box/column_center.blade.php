<div id="latest_news_right">
    @include("frontend.desktop.box.news_r00",[$columnCenter])
</div>
<div id="latest_news_left">
    @include("frontend.desktop.box.news_r01n",[$columnCenter])
    <div class="headline_banner">@include("frontend.desktop.adv.wataniya_160_600")</div>
</div>
<div class="clearer"> </div>
@include("frontend.desktop.box.news_r02",$columnCenter)
@include("frontend.desktop.box.news_r03",$columnCenter)
@include("frontend.desktop.box.news_r04",$columnCenter)
@include("frontend.desktop.box.news_r04n",$columnCenter)
@include("frontend.desktop.box.news_r05",$columnCenter)
@include("frontend.desktop.box.news_r06",$columnCenter)
@include("frontend.desktop.box.news_r07",$columnCenter)
@include("frontend.desktop.box.news_r08",$columnCenter)
<div id="health_news_right">
    @include("frontend.desktop.box.news_r09n",$columnCenter)
</div>
<div id="health_news_left">
    @include("frontend.desktop.box.news_r10n",$columnCenter)
</div>
<div class="clearer"> </div>
@include("frontend.desktop.box.news_r11n",$columnCenter)
@include("frontend.desktop.box.news_r12",$columnCenter)
