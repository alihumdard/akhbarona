<span class="story_date_bh_sw">{{\Carbon\Carbon::createFromFormat("Y-m-d H:i:s",$article->created)->format("h:i")}}</span>
