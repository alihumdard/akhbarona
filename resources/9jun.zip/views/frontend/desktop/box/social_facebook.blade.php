<div align="center">

    <iframe src="//www.facebook.com/plugins/share_button.php?href={{Common::article_link($article)}}&amp;layout=button_count" scrolling="no" frameborder="0" style="border:none; overflow:hidden;" allowTransparency="true"
            height="20" width="150"></iframe>

</div>
