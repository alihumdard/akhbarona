@include("frontend.desktop.adv.left_banner_1")
@include("frontend.desktop.adv.left_banner_home_2")
@include("frontend.desktop.box.news_l1",$columnLeft)
@include("frontend.desktop.box.news_l2",$columnLeft)
@include("frontend.desktop.box.news_l3",$columnLeft)
@include("frontend.desktop.box.news_l4",$columnLeft)
@include("frontend.desktop.box.news_l8",$columnLeft)
@include("frontend.desktop.box.news_l5",$columnLeft)

<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fakhbaronacom%2F&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

