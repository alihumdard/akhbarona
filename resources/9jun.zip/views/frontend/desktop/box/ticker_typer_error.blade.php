<div id="content_sw">
    <ul class="ticker">

        <li class="category" style="display: none">

        </li>

    </ul>
</div>
