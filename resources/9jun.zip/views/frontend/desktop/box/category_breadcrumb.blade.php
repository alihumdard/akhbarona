<div class="box_breadcrumb">
    <a href="{{Config::get("app.url")}}">{{Config::get("site.lang.LNG_GO_HOME")}}</a> |
    {{$category->category_name}}
</div>
