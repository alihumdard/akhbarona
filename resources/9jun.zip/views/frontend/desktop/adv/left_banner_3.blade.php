<!-- Fixed left 3 -->

<!-- /1019170/Akhbarona_Left_Banner_3 -->
<div id='div-gpt-ad-1545660622806-0'>
    <script>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1545660622806-0'); });
    </script>
</div>
