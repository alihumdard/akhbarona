<!-- /1019170/Akhbarona_160x600_Homepage_Under_Wataniya -->
<div id='div-gpt-ad-1521102400350-7' style='height:600px; width:160px;'>
<script>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1521102400350-7'); });
</script>
</div>
