<p></p>
<!-- Fixed left home 2 -->
<div class="headline_banner">

    <!-- /1019170/IAM_Banner1_300x250 -->
    <div id='div-gpt-ad-1518636279794-0' style='height:250px; width:300px;'>
        <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1518636279794-0'); });
        </script>
    </div>

</div>
