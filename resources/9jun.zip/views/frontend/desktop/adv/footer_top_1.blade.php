<center>
<!-- /1019170/Akhbarona_Footer_Desktop -->
<div id='div-gpt-ad-1544959375426-0'>
<script>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1544959375426-0'); });
</script>
</div>
</center>


<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
_atrk_opts = { atrk_acct:"6Y56g1agwt00Oe", domain:"akhbarona.com",dynamic: true};
(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://certify.alexametrics.com/atrk.gif?account=6Y56g1agwt00Oe" style="display:none" height="1" width="1" alt="" /></noscript>
<!-- End Alexa Certify Javascript -->


<!-- Begin 33Across SiteCTRL -->
<script>
var Tynt=Tynt||[];Tynt.push('dqmgEkqFyr4RJ8acwqm_6r');
(function(){var h,s=document.createElement('script');
s.src=(window.location.protocol==='https:'?
'https':'http')+'://cdn.tynt.com/ti.js';
h=document.getElementsByTagName('script')[0];
h.parentNode.insertBefore(s,h);})();
</script>
<!-- End 33Across SiteCTRL -->

<div data-id='_mwayss-a4f30579286fa29fb759a31473057ef2'></div>
                    <script>
                        (function(window, document, undefined) {
                            var script_tag = document.createElement('script');
                            script_tag.src =
'https://ad.mox.tv/mox/mwayss_invocation.min.js?pzoneid=2799&height=288&width=512&tld=akhbarona.com&ctype=div';
                            var container =
document.querySelectorAll('[data-id=_mwayss-a4f30579286fa29fb759a31473057ef2]')[0];

                            container.setAttribute('id',
(container.getAttribute('data-id')+(new
Date()).getTime()));
                            container.removeAttribute('data-id');
                            container.parentNode.insertBefore(script_tag, container);
                        })(window, document);
                    </script>




