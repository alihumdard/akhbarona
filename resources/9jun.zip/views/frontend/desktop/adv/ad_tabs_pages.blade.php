<div class="ad_tabs_right">@include("frontend.desktop.adv.top_right_160_600")</div>
<div class="ad_tabs_left">@include("frontend.desktop.adv.top_left_160_600")</div>
