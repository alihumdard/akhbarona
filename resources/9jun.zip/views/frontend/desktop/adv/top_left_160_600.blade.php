<!-- /1019170/Akhbarona_Top_160x600_Left -->
<div id='div-gpt-ad-1521102400350-4' style='height:600px; width:160px;'>
<script>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1521102400350-4'); });
</script>
</div>
