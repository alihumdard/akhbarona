<!-- START Ads Tabs By Sawa24.com -->
<div class="ad_tabs_right">@include("frontend.desktop.adv.top_right_160_600")</div>
<!-- END Ads Tabs By Sawa24.com -->
