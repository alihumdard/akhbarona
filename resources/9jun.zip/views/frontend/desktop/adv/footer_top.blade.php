<center>
    <!-- /1019170/Akhbarona_Footer_Desktop -->
    <div id='div-gpt-ad-1544959375426-0'>
        <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1544959375426-0'); });
        </script>
    </div>
</center>


<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
    _atrk_opts = { atrk_acct:"6Y56g1agwt00Oe", domain:"akhbarona.com",dynamic: true};
    (function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://certify.alexametrics.com/atrk.gif?account=6Y56g1agwt00Oe" style="display:none" height="1" width="1" alt="" /></noscript>
<!-- End Alexa Certify Javascript -->


<!-- Begin 33Across SiteCTRL -->
<script>
    var Tynt=Tynt||[];Tynt.push('dqmgEkqFyr4RJ8acwqm_6r');
    (function(){var h,s=document.createElement('script');
        s.src=(window.location.protocol==='https:'?
            'https':'http')+'://cdn.tynt.com/ti.js';
        h=document.getElementsByTagName('script')[0];
        h.parentNode.insertBefore(s,h);})();
</script>
<!-- End 33Across SiteCTRL -->
