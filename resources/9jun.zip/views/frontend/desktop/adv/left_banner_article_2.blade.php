<div><a href="{{Config::get("app.url")}}publish.html" target="_self"><img
            src="{{Config::get("app.cdn_url")}}files/banners/300x100_618624471.jpg" border="0" width="300" height="90"/></a>
</div>
