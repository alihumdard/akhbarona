<script type="text/javascript" class="teads" async="true" src="//a.teads.tv/page/93151/tag"></script>

<div id="jubna2430"></div>
<script type="text/javascript">
    (function() {
        var params =
            {
                id: "293bad80-4584836d-bd8685fc-e75a2d15",
                d: "YWJvdWRjcm0uY29t",
                cb: ((new Date()).valueOf().toString())
            };
        var qs="";
        for(var key in params){qs+=key+"="+params[key]+"&"}
        qs=qs.substring(0,qs.length-1);
        var s = document.createElement("script");
        s.type= "text/javascript";
        s.setAttribute("data-cfasyn", "false");
        s.src = "https://jubna.com/ar/api/widget/2430?" + qs;
        s.async = true;
        document.getElementById("jubna2430").appendChild(s);
    })();
</script>
