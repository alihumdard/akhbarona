<center>
    <!-- /1019170/Akhbarona_Mobile_Middle_1 -->
    <div id='div-gpt-ad-1520681989263-1'>
        <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1520681989263-1'); });
        </script>
    </div>
</center>
