<center>
    <!-- /1019170/Akhbarona_Mobile_Middle_2 -->
    <div id='div-gpt-ad-1550918872422-0'>
        <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1550918872422-0'); });
        </script>
    </div>
</center>
