<!-- Fixed Top -->

<center>
    <!-- /1019170/Akhbarona_Top_Mobile -->
    <div id='div-gpt-ad-1520681989263-3'>
        <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1520681989263-3'); });
        </script>
    </div>
</center>

<script src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({
        google_ad_client: "ca-pub-6335589077419475",
        enable_page_level_ads: true
    });
</script>
