<?php
/*define("HOSTNAME","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","akhbarona");*/

define("HOSTNAME","localhost");
define("USERNAME","akhbar_viv");
define("PASSWORD","459008Nn");
define("DATABASE","akhbar_viv");

/*define("HOSTNAME","localhost");
define("USERNAME","u737368432_123");
define("PASSWORD","123456");
define("DATABASE","u737368432_game");*/

class SQLServices{
	 
	var $result;
	var $connection;
	function SQLServices(){
		$this->get_connection();
	}
	
	function get_connection(){
		$this->connection=mysql_connect(HOSTNAME,USERNAME,PASSWORD);
		mysql_select_db(DATABASE);
	}
	function executequery($query){
		$this->result = mysql_query($query);
		return $this->result;
	}
	function getObject($result){
		return mysql_fetch_object($result);
	}
	function getRowCount($result){
		return mysql_num_rows($result);
	}
	function getRow($result){
		return mysql_fetch_row($result);
	}
	function getArray($result){
		return mysql_fetch_array($result);
	}
	function getAssoc($result){
		return mysql_fetch_assoc($result);
	}
	function getInsertId(){
		return mysql_insert_id();
	}
	function closeConnection(){
		mysql_close($this->connection);
	}
	function getRows($result){
		return mysql_num_rows($result);
	}
	function getAffectedRows(){
		return mysql_affected_rows();
	}
}
?>